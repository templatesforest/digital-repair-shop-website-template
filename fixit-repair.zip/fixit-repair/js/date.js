// JavaScript Document
 
  // taxi datepick script
$(document).ready(function() {
 "use strict";
$('#date').datepick({dateFormat: 'dd-mm-yyyy'}); 
});