// JavaScript Document
 
  $(document).ready(function(){
  	"use strict";
	  $('.slider').slick({
         slidesToShow: 1,
          autoplay: true,
          autoplaySpeed: 2000,
          dots: true,
		});

	});